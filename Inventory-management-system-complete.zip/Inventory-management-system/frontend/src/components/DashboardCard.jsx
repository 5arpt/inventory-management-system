// Dashboard card component
