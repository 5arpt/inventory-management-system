// Product form component
