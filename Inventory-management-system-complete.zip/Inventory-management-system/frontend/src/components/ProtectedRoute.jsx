// Protected route component
