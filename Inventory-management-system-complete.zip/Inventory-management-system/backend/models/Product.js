// Product model
