// Auth middleware
